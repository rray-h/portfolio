import * as flsFunctions from "./modules/function.js";

flsFunctions.isWebp();

const burger = document.querySelector('.header__burger');
const menu = document.querySelector('.menu');
const body = document.querySelector('body');

if(burger && menu) {
    burger.addEventListener('click',() => {
        burger.classList.toggle('active');
        menu.classList.toggle('active');
        body.classList.toggle('lock');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    })
}
