const burger = document.querySelector('.header__burger');
const menu = document.querySelector('.menu');
const body = document.querySelector('body');
const searchButton = document.querySelector('.header__button-search');
const searchInput = document.querySelector('.header__input');

if(burger && menu) {
    burger.addEventListener('click', () => {
        burger.classList.toggle('active');
        menu.classList.toggle('active');
        body.classList.toggle('lock');
    })

    searchButton.addEventListener('click', () => {
        searchInput.classList.toggle('active');
    })
}

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}