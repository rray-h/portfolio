import * as flsFunctions from "./modules/function.js";

flsFunctions.isWebp();

$(document).ready(function() {
    $('.header__burger').click(function() {
        $('.header__burger, .header__menu').toggleClass('active');
        $('body').toggleClass('lock');
        $('.header__logo').toggleClass('hide');
    });
});

