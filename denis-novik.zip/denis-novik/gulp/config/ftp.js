export let configFTP = {
    host: "194.58.122.102", //Адрес FTP сервера
    user: "applmqup", //Имя пользователя
    password: "g12ak2LJw7", //Пароль
    parallel: 5 //Кол-во потоков
}